// ==UserScript==
// @name         debug
// @namespace    https://github.com/yeomanye
// @version      0.9
// @include      *://*
// @description  (�Մ,�
// @author       Ming Ye
// ==/UserScript==

(function(context) {
    var debugD = true; //debugؤ�n
    //��Sp
    var consoleFactory = function(groupName, styleStr, type, debugMode) {
        debugMode = (debugMode === undefined) ? myDebugger.debugD : debugMode;
        type = type || 'log';
        /**
         * ���Sp��
         * @param  {bool} debugMode /&/(��
         */
        var log = function() {
            //��\
            log.init();
            if (log.debugMode) {
                var argArr = Array.prototype.slice.apply(arguments);
                console[type].apply(null, argArr);
            }
        }
        log.debugMode = debugMode;
        /**
         * ��\
         */
        log.init = function(){
            if (!log.nFirst) {
                log.nFirst = true;
                log.groupName = log.groupName || groupName;
                console.group('%c' + log.groupName, styleStr);
            }
        }
        /**
         * Sp�a
         * @param  {string} desc �a��
         * @param  {object} obj  �apn
         */
        log.logObj = function(desc, obj) {
            log.init();
            if (this.debugMode) {
                var argArr = [].slice.call(arguments);
                var desc = argArr.shift();
                argArr.unshift('color:green');
                argArr.unshift(`%c[${desc}]`);

                console.log.apply(console,argArr);
            }
        }
        /**
         * Spp�
         * @param  {string} desc p���
         * @param  {array} arr  p�{�
         */
        log.logArr = function(desc, arr) {
            log.init();
            if (this.debugMode) {
                var argArr = [].slice.call(arguments);
                var desc = argArr.shift();
                console.group(`%c[${desc}]`, 'color:blue;font-size:13px');
                argArr.forEach(item=>{
                    console.table(item);
                });
                console.groupEnd();
            }
        }
        /**
         * �n���
         * @param  {string}  groupName ��
         * @param  {Boolean} debugMode /&/(��
         */
        log.reset = function(groupName, debugMode) {
            console.groupEnd();
            log.nFirst = false;
            log.debugMode = (debugMode === undefined) || true;
            log.groupName = groupName || this.groupName;
        }
        /**
         * � 
         * @param  {bool} expr      h�
         * @param  {string} msg       �o
         * @param  {bool} debugMode /&/(
         */
        log.assert = function(expr,msg,debugMode){
            debugMode = (debugMode === undefined) || this.debugMode;
            if(debugMode){
                console.assert(expr,msg);
            }
        }
        /**
         * : (���>:�:
         * @param  {string} desc    :��
         * @param  {string} bgColor �r
         */
        log.em = function(desc, bgColor) {
            log.init();
            bgColor = bgColor || 'green';
            if (debugMode) {
                console.log(`%c${desc}`, `font-size:18px;background-color:${bgColor};color:white;padding:4px`);
            }
        }
        return log;
    }

    // S�p:true� /�
    var debugTrue = function(debugMode) {
        debugMode = (debugMode === undefined) ? myDebugger.debugD : debugMode;
        if (debugMode) debugger;
    }

    var myDebugger = {
        consoleFactory: consoleFactory,
        debugTrue: debugTrue,
        debugD:debugD
    };

    context.myDebugger = myDebugger;

})(window);
